import asyncio
import json
import os
import ssl
from dotenv import load_dotenv
from web3 import Web3
from web3.exceptions import BlockNotFound
from web3.middleware import geth_poa_middleware
from helpers.modal import Modal as md
from helpers.dbhelper import Database as Db

load_dotenv()

# Connection to Celo network (replace with your provider URL)
provider_url = os.getenv('CELO_PROVIDER_URL', 'https://forno.celo.org')
web3 = Web3(Web3.WebsocketProvider(provider_url))
web3.middleware_onion.inject(geth_poa_middleware, layer=0)

# Load ABIs from files
def load_abi(name):
    with open(f'abi/{name}.json', 'r') as abi_file:
        return json.load(abi_file)

# Supported currencies with loaded ABIs
supported_currencies = [
    {
        'name': 'cUSD',
        'contract_address': '0x...',
        'abi': load_abi('cusd'),
        'decimals': 18,
        'code': 'cUSD',
        'issuer': 'Celo'
    }
]

# Database functions
def save_last_processed_block_number(block_number):
    Db().Update(
        "ChainBlock", "chain='celo'", **{"chain": 'celo', "last_seen_block": block_number}
    )
    return True

def load_last_processed_block_number():
    result = Db().select(
        "SELECT last_seen_block FROM ChainBlock WHERE chain = %s", ('celo',)
    )
    return result[0]["last_seen_block"] if result else 0  # Default to 0 if no block number is stored

# Event processing
def handle_event(event, currency):
    print("Received a new transaction:", event)
    data = json.loads(Web3.toJSON(event))
    transactionHash = data["transactionHash"]
    args = data["args"]
    amount = args.get('tokens') or args.get('amount')
    process_received_data(args, amount, currency, transactionHash)

def process_received_data(args, amount, currency, transactionHash):
    account_number = args["account_number"]
    service_id = args["service_id"]
    asset_amount = amount / (10 ** currency['decimals'])
    md.payout_callback(
        id=transactionHash,
        account=account_number,
        memo=service_id,
        asset_amount=asset_amount,
        asset_code=currency['code'],
        asset_issuer=currency['issuer'],
        payout_asset=""
    )

# Main event loop
async def log_loop(event_filter, poll_interval, currency):
    last_processed_block = load_last_processed_block_number()
    print("Last processed block:", last_processed_block)

    while True:
        try:
            current_block_number = web3.eth.block_number
            print("Listening for transactions at block:", current_block_number)
            for block_number in range(last_processed_block + 1, current_block_number + 1):
                try:
                    block = web3.eth.get_block(block_number)
                    for transaction in block.transactions:
                        receipt = web3.eth.get_transaction_receipt(transaction.hex())
                        if any(event['transactionHash'] == transaction.hex() for event in event_filter.get_all_entries()):
                            handle_event(receipt, currency)
                    last_processed_block = block_number
                    save_last_processed_block_number(last_processed_block)
                except BlockNotFound:
                    continue
            await asyncio.sleep(poll_interval)
        except KeyboardInterrupt:
            print("Interrupted by user, stopping...")
            break

def main():
    print("Starting ingestion for the Celo contract")
    event_filters = []
    for currency in supported_currencies:
        contract = web3.eth.contract(address=currency['contract_address'], abi=currency['abi'])
        event_filter = contract.events.Pay.createFilter(fromBlock='latest')
        event_filters.append((event_filter, currency))

    loop = asyncio.get_event_loop()
    tasks = [log_loop(event_filter, 1, currency) for event_filter, currency in event_filters]
    loop.run_until_complete(asyncio.gather(*tasks))
    loop.close()

if __name__ == "__main__":
    ssl._create_default_https_context = ssl._create_unverified_context
    main()
